# PlaneCoordinates
Utility to create 2D Coordinate Object types and perform some operations
